# Pandya_Wotton_Midterm_Scaffold

This project is in preparation for midterms, it includes wireframes and pages layed out for the purpose of establishing a grid and layout to be improved for the final FIP assignment.

## Credits
Dev Pandya, Aiden Wotton

## License
MIT